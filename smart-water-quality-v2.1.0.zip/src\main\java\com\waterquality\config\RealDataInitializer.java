package com.waterquality.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

import java.io.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * 真实水质数据初始化器。
 *
 * 从 classpath:data/real_water_quality.csv 加载真实监测数据，
 * 数据来源: 国家地表水水质自动监测实时数据发布系统 / MoonAPI / 青悦API。
 *
 * 激活方式:
 *   java -jar app.jar --spring.profiles.active=demo-real
 *
 * CSV文件格式 (由 scripts/import_real_data.py 生成):
 *   point_id,timestamp,turbidity_ntu,cod_value,ph_value,turbidity_level,
 *   alert_level,sensor_score,image_score,final_score,confidence,
 *   pollution_types,data_source,station_name
 */
@Component
@Profile("demo-real")
public class RealDataInitializer implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(RealDataInitializer.class);
    private final JdbcTemplate jdbc;

    private static final String CSV_RESOURCE_PATH = "data/real_water_quality.csv";

    // 如果classpath没有CSV，尝试外部路径
    private static final String CSV_EXTERNAL_PATH = "data/real_water_quality.csv";

    private static final String[] POINT_NAMES = {"钱塘江监测点A", "富春江监测点B", "新安江监测点C"};
    private static final String[] LOCATIONS = {"钱塘江上游-杭州段", "富春江中游-桐庐段", "新安江上游-淳安段"};

    public RealDataInitializer(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    @Override
    public void run(String... args) {
        log.info("=== Demo-Real mode: loading REAL water quality data ===");

        createTables();
        insertAdminUser();
        insertMonitoringPoints();

        int count = loadRealData();
        if (count > 0) {
            generateAlertRecords();
            log.info("=== Demo-Real mode: loaded {} REAL data records ===", count);
        } else {
            log.warn("=== No real data found. Falling back to demo data ===");
            fallbackToDemoData();
        }

        log.info("Login: admin / admin123");
        log.info("H2 Console: http://localhost:8080/h2-console");
    }

    private void createTables() {
        log.info("Creating tables...");

        jdbc.execute("CREATE TABLE IF NOT EXISTS sys_user (" +
            "id BIGINT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(50) NOT NULL, " +
            "password VARCHAR(200) NOT NULL, phone VARCHAR(20), email VARCHAR(100), " +
            "role VARCHAR(20) NOT NULL DEFAULT 'readonly', status TINYINT NOT NULL DEFAULT 1, " +
            "create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP, update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP, " +
            "CONSTRAINT uk_username UNIQUE (username))");

        jdbc.execute("CREATE TABLE IF NOT EXISTS monitoring_point (" +
            "id BIGINT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL, " +
            "longitude DOUBLE NOT NULL, latitude DOUBLE NOT NULL, device_id VARCHAR(50), " +
            "status TINYINT NOT NULL DEFAULT 0, last_online_time TIMESTAMP, " +
            "location_desc VARCHAR(200), contact_phone VARCHAR(20), " +
            "create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP, update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP, " +
            "CONSTRAINT uk_device_id UNIQUE (device_id))");

        jdbc.execute("CREATE TABLE IF NOT EXISTS water_quality_data (" +
            "id BIGINT AUTO_INCREMENT PRIMARY KEY, point_id BIGINT NOT NULL, " +
            "timestamp TIMESTAMP NOT NULL, turbidity_level TINYINT DEFAULT 0, " +
            "turbidity_ntu DECIMAL(10,2), cod_value DECIMAL(10,2), ph_value DECIMAL(10,2), " +
            "pollution_types VARCHAR(500), alert_level INT DEFAULT 0, " +
            "confidence DECIMAL(10,4), final_score DECIMAL(10,4), " +
            "image_score DECIMAL(10,4), sensor_score DECIMAL(10,4), " +
            "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
        jdbc.execute("CREATE INDEX IF NOT EXISTS idx_wq_point_time ON water_quality_data(point_id, timestamp)");
        jdbc.execute("CREATE INDEX IF NOT EXISTS idx_wq_point_alert ON water_quality_data(point_id, alert_level, final_score)");

        jdbc.execute("CREATE TABLE IF NOT EXISTS alert_record (" +
            "id BIGINT AUTO_INCREMENT PRIMARY KEY, point_id BIGINT NOT NULL, " +
            "alert_level INT NOT NULL, alert_type VARCHAR(100), details CLOB, " +
            "push_status VARCHAR(20) DEFAULT 'pending', retry_count INT DEFAULT 0, " +
            "create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP, update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP, " +
            "confirm_time TIMESTAMP, confirmed_by BIGINT)");
        jdbc.execute("CREATE INDEX IF NOT EXISTS idx_alert_point_time ON alert_record(point_id, create_time)");
        jdbc.execute("CREATE INDEX IF NOT EXISTS idx_alert_retry ON alert_record(push_status, create_time)");

        jdbc.execute("CREATE TABLE IF NOT EXISTS user_point_permission (" +
            "user_id BIGINT NOT NULL, point_id BIGINT NOT NULL, PRIMARY KEY (user_id, point_id))");

        jdbc.execute("CREATE TABLE IF NOT EXISTS edge_device (" +
            "id BIGINT AUTO_INCREMENT PRIMARY KEY, device_sn VARCHAR(50) NOT NULL, " +
            "device_type VARCHAR(50), firmware_version VARCHAR(20), last_heartbeat TIMESTAMP, " +
            "point_id BIGINT, status TINYINT DEFAULT 0, " +
            "create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP, " +
            "CONSTRAINT uk_device_sn UNIQUE (device_sn))");

        jdbc.execute("CREATE TABLE IF NOT EXISTS sys_config (" +
            "id BIGINT AUTO_INCREMENT PRIMARY KEY, config_key VARCHAR(100) NOT NULL, " +
            "config_value CLOB, is_sensitive TINYINT DEFAULT 0, " +
            "CONSTRAINT uk_config_key UNIQUE (config_key))");

        log.info("Tables created (8 tables)");
    }

    private void insertAdminUser() {
        String hash = new BCryptPasswordEncoder().encode("admin123");
        jdbc.update("INSERT INTO sys_user (username, password, phone, email, role, status) VALUES (?,?,?,?,?,?)",
            "admin", hash, "13800000000", "admin@water.com", "admin", 1);
        log.info("Admin user: admin / admin123");
    }

    private void insertMonitoringPoints() {
        // 使用真实站点的精确坐标
        jdbc.update("INSERT INTO monitoring_point (id, name, longitude, latitude, device_id, status, location_desc, contact_phone) VALUES (?,?,?,?,?,?,?,?)",
            1, POINT_NAMES[0], 120.20523, 30.24385, "DEV-QT-001", 1,
            LOCATIONS[0] + " | 数据来源: 国家地表水自动监测(闸口/七堡/萧山)", "13800000001");
        jdbc.update("INSERT INTO monitoring_point (id, name, longitude, latitude, device_id, status, location_desc, contact_phone) VALUES (?,?,?,?,?,?,?,?)",
            2, POINT_NAMES[1], 119.65283, 29.81367, "DEV-FC-001", 1,
            LOCATIONS[1] + " | 数据来源: 国家地表水自动监测(桐庐/富阳/窄溪)", "13800000002");
        jdbc.update("INSERT INTO monitoring_point (id, name, longitude, latitude, device_id, status, location_desc, contact_phone) VALUES (?,?,?,?,?,?,?,?)",
            3, POINT_NAMES[2], 119.04125, 29.60873, "DEV-XA-001", 1,
            LOCATIONS[2] + " | 数据来源: 国家地表水自动监测(洋溪渡/街口/千岛湖)", "13800000003");
        log.info("Monitoring points: 3 (钱塘江/富春江/新安江) — with real station metadata");
    }

    /**
     * 从CSV文件加载真实数据。
     * 优先从classpath读取，fallback到外部文件系统。
     */
    private int loadRealData() {
        List<String[]> rows = null;

        // 尝试从classpath读取
        try {
            ClassPathResource resource = new ClassPathResource(CSV_RESOURCE_PATH);
            if (resource.exists()) {
                rows = parseCsv(new InputStreamReader(resource.getInputStream(), StandardCharsets.UTF_8));
                log.info("Loaded CSV from classpath: {} ({} rows)", CSV_RESOURCE_PATH, rows.size());
            }
        } catch (IOException e) {
            log.debug("Classpath CSV not found: {}", CSV_RESOURCE_PATH);
        }

        // Fallback: 尝试外部文件
        if (rows == null || rows.isEmpty()) {
            File externalFile = new File(CSV_EXTERNAL_PATH);
            if (externalFile.exists()) {
                try (InputStreamReader reader = new InputStreamReader(
                        new FileInputStream(externalFile), StandardCharsets.UTF_8)) {
                    rows = parseCsv(reader);
                    log.info("Loaded CSV from external: {} ({} rows)", CSV_EXTERNAL_PATH, rows.size());
                } catch (IOException e) {
                    log.warn("Failed to read external CSV: {}", e.getMessage());
                }
            }
        }

        if (rows == null || rows.isEmpty()) {
            log.warn("Real data CSV not found. Place it at:");
            log.warn("  - classpath:data/real_water_quality.csv");
            log.warn("  - external: data/real_water_quality.csv");
            log.warn("Run: python scripts/import_real_data.py --input <source>.json");
            return 0;
        }

        return insertRealData(rows);
    }

    /**
     * 简单CSV解析器（不依赖第三方库）。
     * 支持引号包裹的字段和逗号分隔。
     */
    private List<String[]> parseCsv(Reader reader) throws IOException {
        List<String[]> rows = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(reader)) {
            String headerLine = br.readLine(); // 跳过表头
            if (headerLine == null) return rows;

            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                String[] fields = parseCsvLine(line);
                if (fields.length >= 12) {
                    rows.add(fields);
                }
            }
        }
        return rows;
    }

    /**
     * 解析单行CSV，处理引号包裹的字段。
     */
    private String[] parseCsvLine(String line) {
        List<String> fields = new ArrayList<>();
        boolean inQuotes = false;
        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (c == '"') {
                inQuotes = !inQuotes;
            } else if (c == ',' && !inQuotes) {
                fields.add(sb.toString().trim());
                sb.setLength(0);
            } else {
                sb.append(c);
            }
        }
        fields.add(sb.toString().trim());
        return fields.toArray(new String[0]);
    }

    /**
     * 批量插入真实数据到数据库。
     *
     * CSV列顺序 (由 import_real_data.py 生成):
     *   0:point_id, 1:timestamp, 2:turbidity_ntu, 3:cod_value, 4:ph_value,
     *   5:turbidity_level, 6:alert_level, 7:sensor_score, 8:image_score,
     *   9:final_score, 10:confidence, 11:pollution_types, 12:data_source,
     *   13:station_name, 14:water_temp, 15:dissolved_oxygen, 16:nh3n, 17:tp,
     *   18:conductivity
     */
    private int insertRealData(List<String[]> rows) {
        String sql = "INSERT INTO water_quality_data (point_id, timestamp, turbidity_level, " +
            "turbidity_ntu, cod_value, ph_value, pollution_types, alert_level, " +
            "confidence, final_score, image_score, sensor_score) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";

        List<Object[]> batch = new ArrayList<>();
        int total = 0;

        for (String[] row : rows) {
            try {
                int pointId = parseIntSafe(row[0]);
                String timestamp = row[1];
                double turbidityNtu = parseDoubleSafe(row[2]);
                double codValue = parseDoubleSafe(row[3]);
                double phValue = parseDoubleSafe(row[4]);
                int turbidityLevel = parseIntSafe(row[5]);
                int alertLevel = parseIntSafe(row[6]);
                double sensorScore = parseDoubleSafe(row[7]);
                double imageScore = parseDoubleSafe(row[8]);
                double finalScore = parseDoubleSafe(row[9]);
                double confidence = parseDoubleSafe(row[10]);
                String pollutionTypes = row.length > 11 ? row[11] : "[\"unknown\"]";

                batch.add(new Object[]{
                    pointId, timestamp, turbidityLevel,
                    r(turbidityNtu), r(codValue), r(phValue),
                    pollutionTypes, alertLevel,
                    r(confidence), r(finalScore), r(imageScore), r(sensorScore)
                });

                if (batch.size() >= 500) {
                    jdbc.batchUpdate(sql, batch);
                    total += batch.size();
                    batch.clear();
                }
            } catch (Exception e) {
                log.debug("Skip invalid row: {}", e.getMessage());
            }
        }

        if (!batch.isEmpty()) {
            jdbc.batchUpdate(sql, batch);
            total += batch.size();
        }

        log.info("Real water quality data: {} records inserted (from {} CSV rows)", total, rows.size());

        // 打印数据统计
        printDataSummary();
        return total;
    }

    private void printDataSummary() {
        // 统计各监测点数据量和时间范围
        for (int pointId = 1; pointId <= 3; pointId++) {
            Integer count = jdbc.queryForObject(
                "SELECT COUNT(*) FROM water_quality_data WHERE point_id = ?", Integer.class, pointId);
            String latest = jdbc.queryForObject(
                "SELECT MAX(timestamp) FROM water_quality_data WHERE point_id = ?", String.class, pointId);
            String earliest = jdbc.queryForObject(
                "SELECT MIN(timestamp) FROM water_quality_data WHERE point_id = ?", String.class, pointId);

            if (count != null && count > 0) {
                log.info("  {} {}: {} records, {} ~ {}",
                    pointId, POINT_NAMES[pointId - 1], count, earliest, latest);
            }
        }

        // 告警分布
        for (int level = 0; level <= 3; level++) {
            Integer count = jdbc.queryForObject(
                "SELECT COUNT(*) FROM water_quality_data WHERE alert_level = ?", Integer.class, level);
            String[] labels = {"正常", "轻度", "中度", "重度"};
            if (count != null && count > 0) {
                log.info("  {}: {} records", labels[level], count);
            }
        }
    }

    private void generateAlertRecords() {
        int count = jdbc.update(
            "INSERT INTO alert_record (point_id, alert_level, alert_type, details, push_status, retry_count, create_time, confirm_time) " +
            "SELECT point_id, alert_level, 'turbidity,cod', " +
            "'{\"source\":\"real\",\"turbidity\":' || CAST(turbidity_ntu AS VARCHAR) || ',\"cod\":' || CAST(cod_value AS VARCHAR) || ',\"ph\":' || CAST(ph_value AS VARCHAR) || '}', " +
            "CASE WHEN alert_level >= 2 THEN 'sent' ELSE 'pending' END, 0, timestamp, " +
            "CASE WHEN alert_level >= 2 THEN DATEADD('MINUTE', 5, timestamp) ELSE NULL END " +
            "FROM water_quality_data WHERE alert_level >= 1");
        log.info("Alert records: {} generated from real data", count);
    }

    /**
     * 当没有真实数据时，生成模拟数据作为fallback。
     * 使用与DemoDataInitializer相同的算法。
     */
    private void fallbackToDemoData() {
        log.info("=== No real data found. Generating simulated demo data instead ===");
        log.info("To use real data: place CSV at classpath:data/real_water_quality.csv");
        log.info("Run: python scripts/import_real_data.py --input <data>.json");

        java.util.Random rng = new java.util.Random(42);
        LocalDateTime end = LocalDateTime.now();
        LocalDateTime start = end.minusDays(2);
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String sql = "INSERT INTO water_quality_data (point_id, timestamp, turbidity_level, " +
            "turbidity_ntu, cod_value, ph_value, pollution_types, alert_level, " +
            "confidence, final_score, image_score, sensor_score) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";

        List<Object[]> batch = new ArrayList<>();
        int total = 0;
        int intervalMin = 5;

        for (int pointId = 1; pointId <= 3; pointId++) {
            LocalDateTime t = start;
            while (t.isBefore(end)) {
                double hourFactor = 1.0 + 0.3 * Math.sin((t.getHour() - 6) * Math.PI / 12);
                double weekdayFactor = 1.0 + 0.15 * (t.getDayOfWeek().getValue() <= 5 ? 1 : 0);
                double factor = hourFactor * weekdayFactor;
                double ph = 7.0 + rng.nextGaussian() * 0.3;
                double turbidity = Math.abs(rng.nextGaussian() * 3 + 2) * factor;
                double cod = Math.abs(rng.nextGaussian() * 4 + 8) * factor;
                if (rng.nextDouble() < 0.03) turbidity = 50 + rng.nextDouble() * 100;
                if (rng.nextDouble() < 0.05) cod = 30 + rng.nextDouble() * 50;

                int turbidityLevel = turbidity >= 80 ? 3 : turbidity >= 30 ? 2 : turbidity >= 5 ? 1 : 0;
                int alertLevel = turbidity >= 80 || cod >= 50 ? 3 :
                    turbidity >= 30 || cod >= 30 || ph < 6.5 || ph > 8.5 ? 2 :
                    turbidity >= 5 || cod >= 15 ? 1 : 0;
                double imageScore = alertLevel >= 2 ? 0.6 + rng.nextDouble() * 0.38 :
                    alertLevel == 1 ? 0.2 + rng.nextDouble() * 0.35 : 0.01 + rng.nextDouble() * 0.17;
                double sensorScore = Math.min(turbidity / 100, 1.0) * 0.4 +
                    Math.min(cod / 60, 1.0) * 0.35 + Math.min(Math.abs(ph - 7.0) / 3.5, 1.0) * 0.25;
                double finalScore = imageScore * 0.6 + sensorScore * 0.4;
                double confidence = 0.75 + rng.nextDouble() * 0.24;
                String pollutionTypes = alertLevel >= 3 ? "[\"sediment\",\"industrial_waste\"]" :
                    alertLevel == 2 ? "[\"algae\",\"sediment\"]" :
                    alertLevel == 1 ? "[\"algae\"]" : "[\"clear\"]";

                batch.add(new Object[]{pointId, t.format(fmt), turbidityLevel,
                    r(turbidity), r(cod), r(ph), pollutionTypes, alertLevel,
                    r(confidence), r(finalScore), r(imageScore), r(sensorScore)});

                if (batch.size() >= 500) {
                    jdbc.batchUpdate(sql, batch);
                    total += batch.size();
                    batch.clear();
                }
                t = t.plusMinutes(intervalMin);
            }
        }
        if (!batch.isEmpty()) { jdbc.batchUpdate(sql, batch); total += batch.size(); }
        log.info("Fallback demo data: {} records generated", total);
    }

    // ── 工具方法 ──

    private int parseIntSafe(String s) {
        try { return Integer.parseInt(s.trim()); }
        catch (Exception e) { return 0; }
    }

    private double parseDoubleSafe(String s) {
        try { return Double.parseDouble(s.trim()); }
        catch (Exception e) { return 0.0; }
    }

    private static BigDecimal r(double v) {
        return BigDecimal.valueOf(v).setScale(3, RoundingMode.HALF_UP);
    }
}
